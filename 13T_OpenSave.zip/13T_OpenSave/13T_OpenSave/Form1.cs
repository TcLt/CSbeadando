﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _13T_OpenSave
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.FileOk += (sender, e) =>
            {
                try
                {
                    using (var sr = new StreamReader(openFileDialog1.FileName))
                    {
                        lista.Items.Clear();
                        while (!sr.EndOfStream)
                        {
                            lista.Items.Add(sr.ReadLine());
                        }
                    }
                }
                catch (IOException)
                {
                    MessageBox.Show("Hiba! Nem sikerült a betöltés!");
                }
            };
        }

        private void tbBeirtSzoveg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && tbBeirtSzoveg.Text.Trim() != "")
            {
                lista.Items.Add(tbBeirtSzoveg.Text);
                tbBeirtSzoveg.Text = "";
            }
        }

        private void btnMent_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                //File.WriteAllLines(openFileDialog1.FileName, lista.Items.Cast<string>().ToArray())
                using (var sw = new StreamWriter(saveFileDialog1.FileName))
                {
                    foreach (var item in lista.Items)
                    {
                        sw.WriteLine(item);
                    }
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Hiba. Sikertelen mentés!");
            }
        }

        private void btnBetolt_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }
    }
}
