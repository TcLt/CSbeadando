﻿namespace _13T_OpenSave
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lista = new System.Windows.Forms.ListBox();
            this.btnMent = new System.Windows.Forms.Button();
            this.btnBetolt = new System.Windows.Forms.Button();
            this.tbBeirtSzoveg = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Szöveges fájl (.txt)|*.txt|Minden fájl|*.*";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Szöveges fájl (.txt)|*.txt|Minden fájl|*.*";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // lista
            // 
            this.lista.FormattingEnabled = true;
            this.lista.Location = new System.Drawing.Point(232, 12);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(120, 160);
            this.lista.TabIndex = 0;
            // 
            // btnMent
            // 
            this.btnMent.Location = new System.Drawing.Point(13, 84);
            this.btnMent.Name = "btnMent";
            this.btnMent.Size = new System.Drawing.Size(75, 23);
            this.btnMent.TabIndex = 1;
            this.btnMent.Text = "Mentés";
            this.btnMent.UseVisualStyleBackColor = true;
            this.btnMent.Click += new System.EventHandler(this.btnMent_Click);
            // 
            // btnBetolt
            // 
            this.btnBetolt.Location = new System.Drawing.Point(94, 84);
            this.btnBetolt.Name = "btnBetolt";
            this.btnBetolt.Size = new System.Drawing.Size(75, 23);
            this.btnBetolt.TabIndex = 2;
            this.btnBetolt.Text = "Betöltés";
            this.btnBetolt.UseVisualStyleBackColor = true;
            this.btnBetolt.Click += new System.EventHandler(this.btnBetolt_Click);
            // 
            // tbBeirtSzoveg
            // 
            this.tbBeirtSzoveg.Location = new System.Drawing.Point(13, 13);
            this.tbBeirtSzoveg.Name = "tbBeirtSzoveg";
            this.tbBeirtSzoveg.Size = new System.Drawing.Size(195, 20);
            this.tbBeirtSzoveg.TabIndex = 3;
            this.tbBeirtSzoveg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbBeirtSzoveg_KeyDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 215);
            this.Controls.Add(this.tbBeirtSzoveg);
            this.Controls.Add(this.btnBetolt);
            this.Controls.Add(this.btnMent);
            this.Controls.Add(this.lista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ListBox lista;
        private System.Windows.Forms.Button btnMent;
        private System.Windows.Forms.Button btnBetolt;
        private System.Windows.Forms.TextBox tbBeirtSzoveg;
    }
}

